async function summarize() {
  const link = document.getElementById("discordLink").value;
  const resultDiv = document.getElementById("result");

  if (!link) {
    resultDiv.textContent = "❌ Please enter the topic.";
    return;
  }

  resultDiv.innerHTML = '<div class="spinner"></div>';

  try {
    const startDate = document.getElementById("startDate")?.value || "";
    const endDate = document.getElementById("endDate")?.value || "";

    // Area of interest selection
    const selected = document.querySelector('input[name="area"]:checked')?.value;
    const isOther = selected === 'other';
    const customArea = document.getElementById('customArea')?.value?.trim() || '';
    const area = isOther ? customArea : (selected || '');

    // Optional simple validation if only one date provided
    if ((startDate && !endDate) || (!startDate && endDate)) {
      resultDiv.textContent = "❌ Please provide both start and end dates, or leave both empty.";
      return;
    }
    if (startDate && endDate && startDate > endDate) {
      resultDiv.textContent = "❌ Start date must be before end date.";
      return;
    }

    const res = await fetch("http://52.200.222.174:3001/api/summarize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt: link, startDate, endDate, area })
    });
    const data = await res.json();

    let summary = data.summary || "⚠️ Could not generate summary.";
    
    // แปลง **text** เป็นตัวหนา
    summary = summary.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");

    // แปลง bullet (* text) และ bullet + **text** เป็น <ul><li>
    const lines = summary.split(/\r?\n/);
    const htmlLines = [];
    let listStack = [];

    lines.forEach(line => {
      const match = line.match(/^(\s*)\*\s+(.+)/);
      if (match) {
        const indent = match[1].length;
        const content = match[2];

        // ปิด nested list ที่มากกว่าปัจจุบัน
        while (listStack.length > 0 && listStack[listStack.length - 1] >= indent) {
          htmlLines.push('</ul>');
          listStack.pop();
        }

        if (listStack.length === 0 || listStack[listStack.length - 1] < indent) {
          htmlLines.push('<ul>');
          listStack.push(indent);
        }

        htmlLines.push(`<li>${content}</li>`);
      } else {
        // ปิด list ที่เปิดค้างไว้
        while (listStack.length > 0) {
          htmlLines.push('</ul>');
          listStack.pop();
        }
        if (line.trim() !== '') {
          htmlLines.push(`<p>${line.trim()}</p>`);
        }
      }
    });

    // ปิด list ที่เหลือ
    while (listStack.length > 0) {
      htmlLines.push('</ul>');
      listStack.pop();
    }

    summary = htmlLines.join('');


    summary = summary.replace(/\b(deadline|exam|event|meeting)\b/gi,
      match => `<span class="highlight">${match}</span>`);

    resultDiv.innerHTML = summary;
  } catch (err) {
    resultDiv.textContent = "❌ Failed to connect to server.";
  }
}

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Toggle custom area input when "Other" is selected
document.addEventListener('DOMContentLoaded', () => {
  const radios = document.querySelectorAll('input[name="area"]');
  const customAreaInput = document.getElementById('customArea');
  if (!radios.length || !customAreaInput) return;

  function updateVisibility() {
    const selected = document.querySelector('input[name="area"]:checked')?.value;
    if (selected === 'other') {
      customAreaInput.style.display = 'inline-block';
      customAreaInput.focus();
    } else {
      customAreaInput.style.display = 'none';
      customAreaInput.value = '';
    }
  }

  radios.forEach(r => r.addEventListener('change', updateVisibility));
  updateVisibility();
});