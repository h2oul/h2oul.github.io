const inputBox = document.getElementById('inputBox');
const submitBtn = document.getElementById('submitBtn');
const itemList = document.getElementById('itemList');
const statusMessage = document.getElementById('statusMessage');

// Backend API (proxied in VS Code)
const API_BASE = '/proxy/3000/api/items';  // This is correct - matches your app.js routes
const STREAM_API = '/proxy/3000/api/items';
/* ---------- Helpers ---------- */
function createListItem(item) {
  const li = document.createElement('li');
  // support both id and _id
  const id = item.id || item._id;
  li.dataset.id = id;

  const span = document.createElement('span');
  span.textContent = item.text;

  const editBtn = document.createElement('button');
  editBtn.textContent = 'Edit';
  editBtn.className = 'edit';
  editBtn.addEventListener('click', () => editItem(li, id, item.text));

  const delBtn = document.createElement('button');
  delBtn.textContent = 'Delete';
  delBtn.className = 'delete';
  delBtn.addEventListener('click', () => deleteItem(id, li));

  li.appendChild(span);
  li.appendChild(editBtn);
  li.appendChild(delBtn);

  return li;
}

function showMessage(msg, isError = true) {
  statusMessage.textContent = msg;
  statusMessage.style.color = isError ? '#d33' : '#4caf50';
  setTimeout(() => { statusMessage.textContent = ''; }, 3000);
}

/* ---------- API Calls ---------- */
// GET
async function fetchItems() {
  try {
    const res = await fetch(API_BASE);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();

    itemList.innerHTML = '';
    data.forEach(item => itemList.appendChild(createListItem(item)));
  } catch (err) {
    console.error('Error fetching items:', err);
    showMessage('Failed to load items');
  }
}

// POST
async function addItem(text) {
  try {
    const res = await fetch(API_BASE, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    });
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`HTTP ${res.status}: ${errText}`);
    }
    return await res.json();
  } catch (err) {
    console.error("❌ Error adding item:", err);
    showMessage('Error adding item');
  }
}


// PUT
async function updateItem(id, newText) {
  try {
    const res = await fetch(`${API_BASE}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: newText })
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    console.error('Error updating item:', err);
    showMessage('Error updating item');
  }
}

// DELETE
async function deleteItem(id, li) {
  try {
    const res = await fetch(`${API_BASE}/${id}`, { method: 'DELETE' });
    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`HTTP ${res.status}: ${errText}`);
    }
    li.remove();
    showMessage('Item deleted', false);
  } catch (err) {
    console.error('Error deleting item:', err);
    showMessage('Error deleting item');
  }
}

/* ---------- Event Handlers ---------- */
submitBtn.addEventListener('click', async () => {
  const text = inputBox.value.trim();
  if (!text) return;
  streamItem(text);
  const newItem = await addItem(text);
  if (newItem) {
    itemList.appendChild(createListItem(newItem));
    inputBox.value = '';
    inputBox.focus();
    showMessage('Item added!', false);
  }
});

// Enter key shortcut
inputBox.addEventListener('keypress', e => {
  if (e.key === 'Enter') submitBtn.click();
});

function editItem(li, id, oldText) {
  const span = li.querySelector('span');

  const input = document.createElement('input');
  input.type = 'text';
  input.value = oldText;

  const saveBtn = document.createElement('button');
  saveBtn.textContent = 'Save';
  saveBtn.className = 'save';

  saveBtn.addEventListener('click', async () => {
    const newText = input.value.trim();
    if (!newText) return;

    const updated = await updateItem(id, newText);
    if (updated) {
      span.textContent = updated.text;
      li.replaceChild(span, input);
      li.replaceChild(editBtn, saveBtn);
      showMessage('Item updated!', false);
    }
  });

  const editBtn = li.querySelector('.edit');

  li.replaceChild(input, span);
  li.replaceChild(saveBtn, editBtn);
}

/* ---------- Gemini Streaming ---------- */
async function chatWithGemini(inputText) {
  // Make a placeholder for Gemini response
  const li = document.createElement('li');
  li.textContent = `🤖: `;
  itemList.appendChild(li);

  try {
    const res = await fetch(CHAT_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: inputText })
    });

    if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);

    const reader = res.body.getReader();
    const decoder = new TextDecoder("utf-8");

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      const chunk = decoder.decode(value, { stream: true });
      // Split by SSE "data:" lines
      chunk.split("\n").forEach(line => {
        if (line.startsWith("data: ")) {
          const data = line.replace("data: ", "").trim();
          if (data === "[DONE]") return;
          li.textContent += data;
        }
      });
    }
  } catch (err) {
    console.error("❌ Error streaming Gemini:", err);
    showMessage("Error talking to Gemini");
  }
}

async function streamItem(text) {
  const eventSource = new EventSourcePolyfill('/proxy/3001/api/stream', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text }),
    withCredentials: false
  });

  const li = document.createElement('li');
  li.textContent = '🤖 ';
  itemList.appendChild(li);

  eventSource.onmessage = (event) => {
    if (event.data === '[DONE]') {
      eventSource.close();
    } else {
      li.textContent += event.data;
    }
  };

  eventSource.onerror = (err) => {
    console.error('Streaming error:', err);
    eventSource.close();
  };
}


/* ---------- Init ---------- */
fetchItems();