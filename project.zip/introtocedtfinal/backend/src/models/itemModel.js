export default class Item {
  constructor(id, text) {
    this.id = id;
    this.text = text;
  }
}
