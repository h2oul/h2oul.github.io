import { GoogleGenerativeAI } from "@google/generative-ai";

// Lazy initialization to avoid timing issues with env loading
let genAI = null;
let cachedKey = null;

function ensureGenAI() {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error("GEMINI_API_KEY missing");
  }
  if (!genAI || cachedKey !== key) {
    genAI = new GoogleGenerativeAI(key);
    cachedKey = key;
  }
  return genAI;
}

/* ---------- Streaming ---------- */
export async function streamLLM(prompt, res) {
  try {
    const client = ensureGenAI();
    const model = client.getGenerativeModel({
      model: "gemini-2.5-flash",
      systemInstruction: "You are ChronoNavigator, an assistant that summarizes collections of historical news articles into clear, engaging, and easy-to-remember narratives. Always respond in the same language the user uses in their prompt (e.g., Thai → Thai, English → English). Focus only on the specified time period and topic. Extract and explain the key events, causes, and consequences in simple terms that anyone can understand. Present the content as a connected story or timeline, not just a list of facts, and highlight how events link together to aid memory. Keep the narrative concise, avoiding speculation, modern commentary, or unnecessary detail unless explicitly requested. Never introduce responses with phrases like “As ChronoNavigator…”—just provide the story directly.",                                   
      generationConfig: { temperature: 0.6 },
    });
    const stream = await model.generateContentStream(prompt);

    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    });

    for await (const chunk of stream.stream) {
      const text = chunk.text();
      if (text) res.write(`data: ${text}\n\n`);
    }

    res.write("data: [DONE]\n\n");
    res.end();
  } catch (err) {
    console.error("Streaming error:", err);
    if (res && !res.headersSent) {
      res.writeHead(500, { "Content-Type": "text/plain" });
      res.end("Error streaming from Gemini");
    }
  }
}

/* ---------- Normal JSON ---------- */
export async function callLLM(prompt) {
  try {
    const client = ensureGenAI();
    const model = client.getGenerativeModel({
      model: "gemini-2.5-flash",
      systemInstruction: "You are ChronoNavigator, an assistant that summarizes collections of historical news articles into clear, engaging, and easy-to-remember narratives. Always respond in the same language the user uses in their prompt (e.g., Thai → Thai, English → English). Focus only on the specified time period and topic. Extract and explain the key events, causes, and consequences in simple terms that anyone can understand. Present the content as a connected story or timeline, not just a list of facts, and highlight how events link together to aid memory. Keep the narrative concise, avoiding speculation, modern commentary, or unnecessary detail unless explicitly requested. Never introduce responses with phrases like “As ChronoNavigator…”—just provide the story directly.",                                   
      generationConfig: { temperature: 0.6 },
    });
    const response = await model.generateContent(prompt);
    const text = response.response?.text?.() || "[No response]";
    console.log("Gemini response:", text);
    return text;
  } catch (err) {
    console.error("Error calling Gemini:", err?.message || err);
    return "[No response]";
  }
}
