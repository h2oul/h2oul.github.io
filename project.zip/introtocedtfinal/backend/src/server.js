// CRITICAL: Load environment variables FIRST, before any other imports
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

// Get current directory
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load .env file from backend directory
dotenv.config({ path: path.join(__dirname, '.env') });

// Debug environment loading BEFORE importing app
console.log('🔍 Server Environment Debug (BEFORE imports):');
console.log('Current working directory:', process.cwd());
console.log('__dirname (server.js location):', __dirname);
console.log('Loading .env from:', path.join(__dirname, '.env'));
console.log('PORT:', process.env.PORT);
console.log('NODE_ENV:', process.env.NODE_ENV);
console.log('GEMINI_API_KEY exists:', !!process.env.GEMINI_API_KEY);
console.log('GEMINI_API_KEY length:', process.env.GEMINI_API_KEY?.length || 0);
console.log('GEMINI_API_KEY first 10 chars:', process.env.GEMINI_API_KEY?.substring(0, 10) || 'NONE');

// Check if .env file exists
import fs from 'fs';
const envPath = path.join(__dirname, '.env');
console.log('.env file exists:', fs.existsSync(envPath));
if (fs.existsSync(envPath)) {
  console.log('.env file contents preview:', fs.readFileSync(envPath, 'utf8').split('\n').slice(0, 5));
}

// NOW import other modules (after env vars are loaded)
console.log('📦 Now importing app.js...');
import app from './app.js';

// const port = process.env.PORT || 3000;
// // const port = 8080;
// app.listen(port, () => {
//   console.log(`🚀 Server running at http://localhost:${port}`);
// });
const port = process.env.PORT || 3001;
app.listen(port, '0.0.0.0', () => {
  console.log(`🚀 Server running at http://0.0.0.0:${port}`);
});
