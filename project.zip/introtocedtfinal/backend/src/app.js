// app.js
import express from 'express';
import cors from 'cors';
// Remove this line: import dotenv from 'dotenv';
import itemRoutes from './routes/itemRoute.js';
import path from 'path';
import { fileURLToPath } from 'url';

// Remove this line: dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// API routes
app.use('/api', itemRoutes);

// Serve frontend (static build in frontend/public)
app.use(express.static(path.join(__dirname, '../../frontend/public')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../../frontend/public/index.html'));
});

export default app;
