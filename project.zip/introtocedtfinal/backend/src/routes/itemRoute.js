import express from 'express';
import { createItem, getItems, updateItem, deleteItem, summarizePrompt } from '../controllers/itemController.js';
import { streamLLM } from "../services/llmService.js";

const router = express.Router();

router.get('/items', getItems);
router.post('/items', createItem);
router.put('/items/:id', updateItem);      // add UPDATE
router.delete('/items/:id', deleteItem);   // add DELETE

// Example: POST /api/stream
router.post("/stream", async (req, res) => {
  const { text } = req.body;
  await streamLLM(text, res);
});

// Simple summarization endpoint used by frontend/scripts/scripts.js
router.post('/summarize', summarizePrompt);

export default router;
