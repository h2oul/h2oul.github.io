import { callLLM } from "../services/llmService.js";

let items = [];
let currentId = 1;

// GET
export const getItems = (req, res) => {
  res.json(items);
};

// POST - create by generating text via LLM
export async function createItem(req, res) {
  const { text } = req.body;
  if (!text) {
    return res.status(400).json({ error: "No text provided" });
  }

  const geminiReply = await callLLM(text);

  const newItem = { id: currentId++, text: geminiReply };
  items.push(newItem);
  res.status(201).json(newItem);
}

// PUT
export const updateItem = (req, res) => {
  const { id } = req.params;
  const { text } = req.body;

  const item = items.find(i => i.id === Number(id));
  if (!item) return res.status(404).json({ error: "Item not found" });

  item.text = text;
  res.json(item);
};

// DELETE
export const deleteItem = (req, res) => {
  const { id } = req.params;
  const index = items.findIndex(i => i.id === Number(id));
  if (index === -1) return res.status(404).json({ error: "Item not found" });

  const deleted = items.splice(index, 1);
  res.json(deleted[0]);
};

// POST - summarize a Discord link used by frontend/scripts/scripts.js
export async function summarizePrompt(req, res) {
    const { prompt, discordLink, startDate, endDate,area } = req.body || {};
  const userInput = prompt || discordLink;
  if (!userInput) {
    return res.status(400).json({ error: "No prompt provided" });
  }
  try {
    const fixedPrompt = `You are ChronoNavigator, an assistant that summarizes collections of historical news articles into clear, engaging, and easy-to-remember narratives. Always respond in the same language the user uses in their prompt (e.g., Thai → Thai, English → English). Focus only on the specified time period and topic. Extract and explain the key events, causes, and consequences in simple terms that anyone can understand. Present the content as a connected story or timeline, not just a list of facts, and highlight how events link together to aid memory. Keep the narrative concise, avoiding speculation, modern commentary, or unnecessary detail unless explicitly requested. Never introduce responses with phrases like “As ChronoNavigator…”—just provide the story directly.`;

    // If a date range is provided, instruct the model to restrict to that range
    const dateRangeInstruction = (startDate && endDate)
      ? `Only include updates between ${startDate} and ${endDate} (inclusive). Ignore content outside this range.`
      : '';

    // If an area is provided, instruct the model to focus on it
    const areaInstruction = area
      ? `Geographic or topical focus: ${area}. Restrict coverage to this focus and ignore unrelated regions or domains.`
      : '';

    const composedPrompt = [fixedPrompt, dateRangeInstruction, areaInstruction, `User input: ${userInput}`]
      .filter(Boolean)
      .join("\n\n");

    const summary = await callLLM(composedPrompt);
    res.json({ summary });
  } catch (err) {
    console.error('Summarize error:', err);
    res.status(500).json({ error: 'Failed to summarize' });
  }
}
